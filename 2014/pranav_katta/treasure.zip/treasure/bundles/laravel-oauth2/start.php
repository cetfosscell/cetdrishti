<?php

Autoloader::map(array('OAuth2' => __DIR__.'/OAuth2.php'));