

<!doctype html>
<html lang="en">
<head>
  <title>BrainStrain | correct </title>
  <meta name="description" content="brainstrain is the online treasure hunt as a part of dhwani13 cet">
  <meta name="keywords" content="online,treasure,hunt,cet,dhwani,cetdhwani,13,puzzle,">
  <meta property="og:site_name" content="brainstrain is the online treasure hunt as a part of dhwani13 cet">
<meta property="og:title" content="Brainstrain13">
<meta property="og:description" content="Be warned, this person may undergo a meltdown any time, he has taken the ultimate triage and started playing brainstrain">
<meta property="og:image" content="https://fbcdn-profile-a.akamaihd.net/hprofile-ak-ash4/373159_158083080875524_1132952370_q.jpg">
<meta property="og:url" content="http://treasure.cetdhwani.com">
  <link rel="stylesheet" type="text/css" href="css/style.css">
<link href='http://fonts.googleapis.com/css?family=Roboto+Condensed:300' rel='stylesheet' type='text/css'>
</head>
<body class="wfull">
<a class="back_h" href="/">Back Home</a>
  <div class="row">
    <div class="c6 holer s3">

        <h1>RULES</h1>
        <div style="text-align: left;line-height: 40px;
  font-size: 20px;">
           1. Your mouse has no warranty i guess, but that should not keep you from clicking the submit button too much.<br>
 
2. Google for a website called google, it has all the answers, i've heard.<br>
 
3. If google is god, admin is google.<br>
 
4. Hacking might be a show off of your skills, but it is mighty easy for us to click on the "Ban" button. Be warned, your names will be blacklisted.<br>
 
5. Dont let a monkey faceroll on your keyboard, most of the characters aint allowed. Type your answers without special characters, spaces or caps For example : Let the answer be "Chelsea Football Club", what the engine recognizes is only "chelseafootballclub".<br>
 
6.Feel free to beg for clues, we will just enjoy holding the answers right above your nose.Start solving, godspeed.<br><br><br>
        </div>
      
      
      
    </div>
    
  </div>

</body>
</html>
