
<!DOCTYPE html>

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title></title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width">

        <link href="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.0/css/bootstrap-combined.min.css" rel="stylesheet">
        <script src="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.0/js/bootstrap.min.js"></script>
        <link rel="stylesheet" type="text/css" href="css/stl.css">
    </head>
    <body>
        
        <div class="container">

      <form class="form-signin" action="sudo/login" method="post">
        <h2 class="form-signin-heading">Please sign in</h2>
        <input type="text" class="input-block-level" name="username" placeholder="Email address">
        <input type="password" class="input-block-level" name="password" placeholder="Password">
        
        <button class="btn btn-large btn-primary" type="submit">Sign in</button>
      </form>

    </div>

       
    </body>
</html>
